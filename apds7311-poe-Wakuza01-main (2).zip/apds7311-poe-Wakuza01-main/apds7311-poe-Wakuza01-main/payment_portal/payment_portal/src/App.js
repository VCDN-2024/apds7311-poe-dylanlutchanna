import React, { useState } from 'react';
import EmployeeLoginForm from './components/EmployeeLoginForm';
import LoginForm from './components/LoginForm';
import TransactionManagement from './components/TransactionManagement';
import PaymentForm from './components/PaymentForm';
import RegistrationForm from './components/RegistrationForm'; // Import RegistrationForm
import './App.css';

function App() {
  const [view, setView] = useState('landing');

  const onEmployeeLoginSuccess = () => {
    setView('transaction'); 
  };

  const onCustomerLoginSuccess = () => {
    setView('payment'); 
  };

  const showEmployeeLogin = () => setView('employee');
  const showLoginForm = () => setView('customer');
  const showRegistrationForm = () => setView('register'); // Add function to show registration form

  // Function to navigate back to the landing view
  const goBackToLanding = () => setView('landing');
  const goBackToLogin = () => setView('customer'); // Add function to navigate back to login

  return (
    <div className="App">
      <h1>International Payment Portal</h1>
      {view === 'landing' && (
        <div>
          <button onClick={showEmployeeLogin}>Employee</button>
          <button onClick={showLoginForm}>Customer</button>
        </div>
      )}
      {view === 'employee' && (
        <EmployeeLoginForm onLoginSuccess={onEmployeeLoginSuccess} onBack={goBackToLanding} />
      )}
      {view === 'customer' && (
        <LoginForm onLoginSuccess={onCustomerLoginSuccess} onBack={goBackToLanding} onRegister={showRegistrationForm} />
      )}
      {view === 'transaction' && (
        <TransactionManagement onBack={goBackToLanding} />
      )}
      {view === 'payment' && <PaymentForm />}
      {view === 'register' && <RegistrationForm onBack={goBackToLogin} />} {/* Pass onBack to RegistrationForm */}
    </div>
  );
}

export default App;