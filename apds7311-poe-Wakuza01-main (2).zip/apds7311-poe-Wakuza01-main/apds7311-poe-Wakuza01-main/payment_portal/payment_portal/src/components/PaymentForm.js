import React, { useState } from 'react';
import './PaymentForm.css';
import axios from 'axios';

const PaymentForm = () => {
  const [formData, setFormData] = useState({
    accountNumber: '',
    amount: '',
    currency: 'USD',
    provider: 'SWIFT',
    recipientAccount: '',
    swiftCode: ''
  });
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/make-payment', formData);
      if (response.data.success) {
        setError(null);
        console.log("Payment successful");
      }
    } catch (error) {
      setError("Error processing payment. Please try again.");
    }
  };

  return (
    <div className="wrapper">
      <div className="payment">
        <h2>Payment Form</h2>
        <form onSubmit={handleSubmit}>
          <div className="form">
            <div className="card">
              <label className="label">Account Number:</label>
              <input
                type="text"
                name="accountNumber"
                className="input"
                placeholder="Account Number"
                onChange={handleChange}
                required
              />
            </div>
            <div className="card">
              <label className="label">Amount:</label>
              <input
                type="number"
                name="amount"
                className="input"
                placeholder="Amount"
                onChange={handleChange}
                required
              />
            </div>
            <div className="card">
              <label className="label">Currency:</label>
              <select name="currency" className="input" onChange={handleChange} required>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
              </select>
            </div>
            <div className="card">
              <label className="label">Provider:</label>
              <select name="provider" className="input" onChange={handleChange} required>
                <option value="SWIFT">SWIFT</option>
              </select>
            </div>
            <div className="card">
              <label className="label">Recipient Account:</label>
              <input
                type="text"
                name="recipientAccount"
                className="input"
                placeholder="Recipient Account"
                onChange={handleChange}
                required
              />
            </div>
            <div className="card">
              <label className="label">SWIFT Code:</label>
              <input
                type="text"
                name="swiftCode"
                className="input"
                placeholder="SWIFT Code"
                onChange={handleChange}
                required
              />
            </div>
            <div className="btn">
              <button type="submit">Pay Now</button>
            </div>
            {error && <p className="error">{error}</p>}
          </div>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;

