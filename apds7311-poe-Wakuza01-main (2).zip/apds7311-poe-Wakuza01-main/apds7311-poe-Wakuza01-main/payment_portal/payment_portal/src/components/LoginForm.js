import React, { useState } from 'react';
import axios from 'axios';

function LoginForm({ onLoginSuccess, onBack, onRegister }) {
    const [accountNumber, setAccountNumber] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('/api/login-customer', { accountNumber, password });
            if (response.data.success) {
                setMessage("Login successful!");
                onLoginSuccess();
            } else {
                setMessage("Invalid credentials.");
            }
        } catch (error) {
            setMessage("Error logging in.");
        }
    };

    return (
        <div>
            <button onClick={onBack} className="back-button">Back</button>
            <h2>Customer Login</h2>
            <form onSubmit={handleLogin}>
                <div>
                    <label>Account Number:</label>
                    <input
                        type="text"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        required
                        placeholder="Enter your account number"
                    />
                </div>
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        placeholder="Enter your password"
                    />
                </div>
                <button type="submit">Login</button>
            </form>
            {message && <p>{message}</p>}
            <p>Don't have an account? <button onClick={onRegister} className="register-button">Register here</button></p>
        </div>
    );
}

export default LoginForm;